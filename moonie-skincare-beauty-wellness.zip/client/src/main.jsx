import React, {useMemo, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {Search, ShoppingCart, UserRound, Heart, Menu, Leaf, ShieldCheck, Truck, Star, X, Plus, Minus} from 'lucide-react';
import './styles.css';

const products = [
 {id:'p1',name:'Neem Face Wash',category:'Face Care',price:299,old:349,rating:'4.8',tag:'Bestseller',tone:'green',desc:'A refreshing daily cleanser inspired by neem.'},
 {id:'p2',name:'Aloe Vera Gel',category:'Face Care',price:349,old:399,rating:'4.7',tag:'Popular',tone:'aloe',desc:'Lightweight hydration for a fresh, dewy feel.'},
 {id:'p3',name:'Kumkumadi Face Cream',category:'Face Care',price:499,old:599,rating:'4.9',tag:'New',tone:'gold',desc:'A rich, luxurious face cream for your evening routine.'},
 {id:'p4',name:'Hair Growth Oil',category:'Hair Care',price:399,old:449,rating:'4.6',tag:'Bestseller',tone:'oil',desc:'A botanical-inspired hair oil for scalp massage.'},
 {id:'p5',name:'Ubtan Face Pack',category:'Body Care',price:325,old:375,rating:'4.7',tag:'Natural',tone:'sand',desc:'A traditional-inspired powder face pack.'},
 {id:'p6',name:'Rose Water Toner',category:'Face Care',price:249,old:299,rating:'4.8',tag:'Gentle',tone:'rose',desc:'A light floral mist for your skincare routine.'}
];
const categories = [{name:'Face Care',sub:'Glow & Shine',icon:'✿'},{name:'Hair Care',sub:'Strong & Healthy',icon:'❋'},{name:'Body Care',sub:'Soft & Smooth',icon:'❀'},{name:'Herbal Range',sub:'Pure & Natural',icon:'❧'},{name:'Gift Sets',sub:'Made for loved ones',icon:'♧'}];
const money = n => '₹'+n.toLocaleString('en-IN');

function App(){
 const [cart,setCart]=useState([]);
 const [query,setQuery]=useState('');
 const [category,setCategory]=useState('All');
 const [panel,setPanel]=useState('');
 const [notice,setNotice]=useState('');
 const [form,setForm]=useState({name:'',email:'',phone:'',address:'',pincode:''});
 const [payment,setPayment]=useState('cod');
 const [mobileMenu,setMobileMenu]=useState(false);
 const [favorites,setFavorites]=useState([]);
 const [user,setUser]=useState(null);
 const visible=useMemo(()=>products.filter(p=>(category==='All'||p.category===category||category==='Herbal Range')&&p.name.toLowerCase().includes(query.toLowerCase())),[category,query]);
 const count=cart.reduce((n,p)=>n+p.qty,0), total=cart.reduce((n,p)=>n+p.price*p.qty,0);
 const add=p=>{setCart(old=>old.some(x=>x.id===p.id)?old.map(x=>x.id===p.id?{...x,qty:x.qty+1}:x):[...old,{...p,qty:1}]);setNotice(p.name+' added to cart');setTimeout(()=>setNotice(''),2200)};
 const change=(id,delta)=>setCart(old=>old.map(p=>p.id===id?{...p,qty:p.qty+delta}:p).filter(p=>p.qty>0));
 const startCheckout=()=>{setPanel('checkout')};
 async function submitOrder(e){
   e.preventDefault();
   if(!form.name||!form.phone||!form.address||!form.pincode){setNotice('Please complete delivery details.');return}
   const api=import.meta.env.VITE_API_URL;
   try{
     if(api && payment==='online'){
       const r=await fetch(api+'/payments/create-order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:cart.map(p=>({productId:p.id,quantity:p.qty})),customer:form})});
       if(r.ok){const data=await r.json();setNotice('Backend order created. Connect Razorpay Checkout keys to finish payment.');console.log(data)}
       else setNotice('Online payment setup is not complete yet. Choose COD or configure the backend.');
     } else if(api && payment==='cod'){
       const r=await fetch(api+'/orders/cod',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:cart.map(p=>({productId:p.id,quantity:p.qty})),customer:form})});
       if(r.ok){setCart([]);setPanel('');setNotice('COD order submitted!');return}
       setNotice('API is not ready yet. Please configure backend first.');
     } else setNotice('Store demo only: connect the backend and database before accepting real orders.');
   }catch{setNotice('Could not connect to backend. Start the API and configure the database.')}
 }
 return <div>
  <div className="topbar"><span>✦ Natural Care　•　Pure Ingredients　•　Healthy You</span><span>Free Shipping on Orders Above ₹999　 |　 Track Order</span></div>
  <header className="header">
   <button className="mobile-toggle" onClick={()=>setMobileMenu(!mobileMenu)}><Menu/></button>
   <a className="brand" href="#"><span className="moon">☾</span><span><b>MOONIE</b><small> B E A U T Y &amp; W E L L N E S S</small></span></a>
   <nav className={mobileMenu?'nav open':'nav'}><a href="#">Home</a><a href="#shop" onClick={()=>setCategory('All')}>Shop</a><a href="#categories">Categories</a><a href="#story">About Us</a><a href="#footer">Contact</a></nav>
   <label className="search"><Search size={17}/><input placeholder="Search for products..." value={query} onChange={e=>{setQuery(e.target.value);document.getElementById('shop')?.scrollIntoView({behavior:'smooth'})}}/></label>
   <button className="icon-btn" aria-label="Wishlist" onClick={()=>setPanel('wishlist')}><Heart/><sup>{favorites.length}</sup></button>
   <button className="icon-btn" aria-label="Cart" onClick={()=>setPanel('cart')}><ShoppingCart/><sup>{count}</sup></button>
   <button className="icon-btn" aria-label="Login" onClick={()=>setPanel('login')}><UserRound/></button>
  </header>
  <main>
   <section className="hero">
    <div className="hero-copy"><p className="eyebrow">PURE　•　NATURAL　•　AYURVEDIC</p><h1>Reveal Your<br/><em>Natural Glow</em></h1><p className="hero-text">Nature's best care for healthy, radiant and beautiful skin — only at MOONIE — Beauty & Wellness.</p><div className="hero-actions"><a className="btn primary" href="#shop">Shop Now <span>→</span></a><a className="btn outline" href="#categories">Explore Our Range</a></div><div className="hero-badges"><span><Leaf/>100% Natural<br/>Ingredients</span><span><ShieldCheck/>Ayurvedic<br/>Formulations</span><span>♡<br/>Cruelty Free</span><span><ShieldCheck/>Safe &<br/>Effective</span></div></div>
    <div className="hero-art"><div className="sun"></div><div className="leaf-shape leaf-one"></div><div className="leaf-shape leaf-two"></div><div className="bottle bottle-one"><small>MOONIE</small><span>Neem<br/>Cleanser</span></div><div className="bottle bottle-two"><small>MOONIE</small><span>Botanical<br/>Serum</span></div><div className="jar"><small>MOONIE</small><span>Face Cream</span></div><div className="hero-note">Healthy Skin ♡<br/>Happy You ♡</div></div>
    <aside className="floating"><span>🌿 <b>Natural<br/>Products</b></span><span>▣ <b>Secure<br/>Payments</b></span><span>🚚 <b>Fast<br/>Delivery</b></span><span>◉ <b>24/7<br/>Support</b></span></aside>
   </section>
   <section className="trust"><div><Leaf/><span><b>Pure Ingredients</b><small>Inspired by nature</small></span></div><div><Truck/><span><b>Free Shipping</b><small>Orders above ₹999</small></span></div><div><ShieldCheck/><span><b>Secure Checkout</b><small>Protected payments</small></span></div><div><Heart/><span><b>Care You Can Trust</b><small>Customer-first service</small></span></div></section>
   <section className="categories section" id="categories"><div className="section-head"><p className="eyebrow">DISCOVER YOUR ROUTINE</p><h2>Shop by Category</h2><p>Thoughtfully chosen care for every day.</p></div><div className="category-grid">{categories.map(c=><button className="category" key={c.name} onClick={()=>{setCategory(c.name);document.getElementById('shop').scrollIntoView({behavior:'smooth'})}}><span className="category-art">{c.icon}</span><b>{c.name}</b><small>{c.sub}</small></button>)}</div></section>
   <section className="story section" id="story"><div className="story-copy"><p className="eyebrow">THE MOONIE PROMISE</p><h2>Ancient Wisdom.<br/><em>Modern Care.</em></h2><p>Discover a mindful skincare ritual inspired by botanicals and traditional beauty practices.</p><ul><li>✓ Thoughtfully selected ingredients</li><li>✓ Care for everyday routines</li><li>✓ Made with a nature-first mindset</li></ul><a className="btn primary" href="#shop">Discover Our Story →</a></div><div className="story-art"><div className="plant">♣</div><div className="stone">✿</div><div className="serum">MOONIE<br/><small>BOTANICAL OIL</small></div></div><div className="offer"><span>Special Offer</span><h3>Find your<br/>daily glow</h3><p>Explore the natural range</p><a href="#shop" className="btn light">Shop Now →</a></div></section>
   <section className="section shop" id="shop"><div className="section-head row-head"><div><p className="eyebrow">CUSTOMER FAVOURITES</p><h2>{category==='All'?'Best Sellers':category}</h2><p>Everyday essentials for your skincare ritual.</p></div><select value={category} onChange={e=>setCategory(e.target.value)}><option>All</option><option>Face Care</option><option>Hair Care</option><option>Body Care</option><option>Herbal Range</option></select></div><div className="product-grid">{visible.map(p=><article className="product" key={p.id}><div className={'product-visual '+p.tone}><span className="tag">{p.tag}</span><button className={'fav '+(favorites.includes(p.id)?'active':'')} onClick={()=>setFavorites(f=>f.includes(p.id)?f.filter(x=>x!==p.id):[...f,p.id])}><Heart size={18} fill={favorites.includes(p.id)?'currentColor':'none'}/></button><div className="pack"><small>MOONIE</small><span>{p.name}</span></div><div className="botanical">✿　❧</div></div><div className="product-info"><small>{p.category}</small><h3>{p.name}</h3><p className="rating"><span>★★★★★</span> <small>({p.rating})</small></p><div className="price"><b>{money(p.price)}</b><del>{money(p.old)}</del><button onClick={()=>add(p)}><Plus size={15}/> Add</button></div></div></article>)}</div>{visible.length===0&&<p>No products found. Try another search.</p>}</section>
   <section className="newsletter"><div><p className="eyebrow">A LITTLE SELF-CARE IN YOUR INBOX</p><h2>Let your natural glow bloom.</h2><p>Get product news, skincare tips and special offers.</p></div><form onSubmit={e=>{e.preventDefault();setNotice('Thanks for subscribing!');e.target.reset()}}><input type="email" placeholder="Enter your email address" required/><button className="btn primary">Subscribe →</button></form></section>
  </main>
  <footer id="footer"><div className="footer-main"><div className="footer-brand"><a className="brand" href="#"><span className="moon">☾</span><span><b>MOONIE</b><small> B E A U T Y &amp; W E L L N E S S</small></span></a><p>Pure ingredients. Thoughtful care.<br/>A little more nature in your daily routine.</p></div><div><h4>Quick Links</h4><a href="#">Home</a><a href="#shop">Shop All</a><a href="#story">Our Story</a><a href="#categories">Categories</a></div><div><h4>Customer Care</h4><button onClick={()=>setPanel('login')}>My Account</button><button onClick={()=>setPanel('orders')}>My Orders</button><a href="#footer">Shipping Policy</a><a href="#footer">Returns & Refunds</a></div><div className="footer-news"><h4>Join the Moon Circle</h4><p>Beauty notes and offers, thoughtfully shared.</p><form onSubmit={e=>{e.preventDefault();setNotice('Thanks for subscribing!');e.target.reset()}}><input type="email" placeholder="Your email address" required/><button>→</button></form><small>Payment options are enabled after gateway setup.</small></div></div><div className="footer-bottom"><span>© 2026 MOONIE — Beauty & Wellness. All rights reserved.</span><span>Privacy Policy　 |　 Terms & Conditions</span></div></footer>
  {notice&&<div className="toast">{notice}<button onClick={()=>setNotice('')}><X size={14}/></button></div>}
  {panel&&<div className="overlay" onClick={()=>setPanel('')}><div className="drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><h2>{({cart:'Your Cart',checkout:'Checkout',login:user?'My Account':'Login / Register',wishlist:'Your Wishlist',orders:'My Orders'})[panel]||panel}</h2><button onClick={()=>setPanel('')}><X/></button></div>
   {panel==='cart'&&<><div className="drawer-body">{cart.length?cart.map(p=><div className="cart-row" key={p.id}><div className={'mini-pack '+p.tone}>M</div><div className="cart-desc"><b>{p.name}</b><small>{money(p.price)}</small><div className="qty"><button onClick={()=>change(p.id,-1)}><Minus size={13}/></button>{p.qty}<button onClick={()=>change(p.id,1)}><Plus size={13}/></button></div></div><b>{money(p.price*p.qty)}</b></div>):<p>Your cart is waiting for something lovely.</p>}</div><div className="drawer-total"><div><span>Subtotal</span><b>{money(total)}</b></div><small>Shipping and taxes calculated at checkout.</small><button className="btn primary full" disabled={!cart.length} onClick={startCheckout}>Proceed to Checkout →</button></div></>}
   {panel==='checkout'&&<form className="checkout-form" onSubmit={submitOrder}><p>Delivery details</p><input placeholder="Full name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/><input type="email" placeholder="Email address" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/><input placeholder="Mobile number" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} required/><textarea placeholder="Full delivery address" value={form.address} onChange={e=>setForm({...form,address:e.target.value})} required/><input placeholder="PIN code" value={form.pincode} onChange={e=>setForm({...form,pincode:e.target.value})} required/><p>Payment method</p><label className="radio"><input type="radio" checked={payment==='cod'} onChange={()=>setPayment('cod')}/> Cash on Delivery (COD)</label><label className="radio"><input type="radio" checked={payment==='online'} onChange={()=>setPayment('online')}/> Online payment (UPI / Cards via Razorpay)</label><div className="checkout-total">Order total <b>{money(total)}</b></div><button className="btn primary full" type="submit">Place Order →</button><small>Online payment becomes live only after secure backend and Razorpay setup.</small></form>}
   {panel==='login'&&<form className="checkout-form" onSubmit={async e=>{e.preventDefault();setNotice('Authentication API must be configured before customer accounts can go live.')}}><p>Welcome to MOONIE — Beauty & Wellness</p><input type="email" placeholder="Email address" required/><input type="password" placeholder="Password (minimum 8 characters)" minLength="8" required/><button className="btn primary full">Continue</button><small>Account security is handled by the backend when configured.</small></form>}
   {panel==='wishlist'&&<div className="drawer-body">{favorites.length?products.filter(p=>favorites.includes(p.id)).map(p=><div className="cart-row" key={p.id}><b>{p.name}</b><b>{money(p.price)}</b><button onClick={()=>add(p)}>Add to cart</button></div>):<p>Tap the heart on a product to save it here.</p>}</div>}
   {panel==='orders'&&<div className="drawer-body"><p>Sign in to view your orders. Customer order history will appear here once the backend is configured.</p><button className="btn primary" onClick={()=>setPanel('login')}>Login / Register</button></div>}
  </div></div>}
 </div>
}
createRoot(document.getElementById('root')).render(<App/>);
