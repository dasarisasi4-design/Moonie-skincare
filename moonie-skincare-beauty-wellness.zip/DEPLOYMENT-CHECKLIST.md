# Live deployment checklist (do this in order)

## 1. Database
Create a PostgreSQL database on a managed provider. Copy its connection string into the API host's `DATABASE_URL`. Run `npx prisma migrate deploy` after setting up the initial migration. Do not commit `.env`.

## 2. Deploy API
Deploy the `server` folder to a Node.js host that supports persistent environment variables and HTTPS. Set `PORT` (host usually sets this), `DATABASE_URL`, a long random `JWT_SECRET`, `CLIENT_ORIGIN` (the final frontend URL), `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET`. Use `npm install`, `npx prisma generate`, and `npm start`. Verify `/api/health`.

## 3. Add products and admin
Seed the database with products and stock. Create an administrator through a controlled one-time process; do not make public registration assign the ADMIN role. The current API includes protected admin routes, but the first admin must be created securely in the database.

## 4. Deploy frontend
Deploy `client` to a static frontend host. Build command: `npm run build`; publish directory: `dist`. Set `VITE_API_URL` to the deployed API URL plus `/api`. Redeploy after changing environment variables.

## 5. Razorpay
Use test mode first. Set up checkout on the frontend with the returned Razorpay order ID, then send checkout success details to `/api/payments/verify`. Configure webhook `/api/payments/webhook` in Razorpay dashboard with the same webhook secret. Do not accept an order as paid based only on frontend callback. Test failed, cancelled, duplicate, and delayed webhook cases. Switch to live keys only after all checks and any required business/KYC approval.

## 6. Shipping and COD
A COD order can be recorded by this starter. To generate labels, live courier tracking and shipment updates, connect a shipping provider account (for example Shiprocket) and implement its API/webhooks. Set shipping fees, COD eligibility, serviceable pincodes, return/refund policy and delivery timelines before launch.

## 7. Before public launch
- Add real product photos, ingredients, sizes, usage directions, and accurate pricing.
- Add privacy policy, terms, shipping, cancellation, returns and refund pages.
- Add email/SMS order confirmation, rate limits, logging, backups and error monitoring.
- Confirm tax invoices/GST requirements with an accountant.
- Test on Android and desktop and place end-to-end test orders.
