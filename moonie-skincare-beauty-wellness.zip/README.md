# MOONIE — Beauty & Wellness — New Store Starter

A new React + Vite storefront and Express API starter for MOONIE — Beauty & Wellness. Includes product browsing, cart, login/register API scaffolding, checkout flow scaffolding for Razorpay and COD, Prisma/PostgreSQL schema, and admin/order API placeholders.

## Important
This is a deployable starter, not yet a live store. Real online payments require your own Razorpay account keys and webhook configuration; real database/orders require a hosted PostgreSQL database; shipping tracking requires a shipping provider account. Never put secret keys in frontend code or share them in chat.

## Requirements
- Node.js 20+
- PostgreSQL database (local or hosted)
- Razorpay account for online payments

## Run locally
### API
1. `cd server`
2. Copy `.env.example` to `.env` and set `DATABASE_URL`, `JWT_SECRET`, and Razorpay keys.
3. `npm install`
4. `npx prisma generate`
5. `npx prisma migrate dev --name init`
6. `npm run dev`

### Web
1. Open another terminal: `cd client`
2. `npm install`
3. Copy `.env.example` to `.env`
4. Set `VITE_API_URL=http://localhost:4000/api`
5. `npm run dev`

Open the Vite URL printed in the terminal.

## Before accepting real orders
- Add production secrets in your hosting provider's environment settings.
- Configure Razorpay webhook endpoint `/api/payments/webhook` and verify signatures.
- Configure email/SMS notifications and a shipping provider integration.
- Add rate limiting, monitoring, backups, privacy/terms/returns pages, tax/shipping rules, and security review.
- Test successful, failed, cancelled, and duplicate payment/webhook scenarios.
