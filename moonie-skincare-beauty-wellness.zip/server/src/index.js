import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Razorpay from 'razorpay';
import crypto from 'node:crypto';
import {PrismaClient} from '@prisma/client';

const app=express();
const prisma=new PrismaClient();
app.use(helmet());
app.use(cors({origin:process.env.CLIENT_ORIGIN?.split(',')||'http://localhost:5173'}));
app.use(express.json({limit:'100kb'}));

const productsSeed=[
 {id:'p1',name:'Neem Face Wash',category:'Face Care',description:'A refreshing daily cleanser inspired by neem.',pricePaise:29900,stock:50},
 {id:'p2',name:'Aloe Vera Gel',category:'Face Care',description:'Lightweight hydration for a fresh, dewy feel.',pricePaise:34900,stock:50},
 {id:'p3',name:'Kumkumadi Face Cream',category:'Face Care',description:'A rich, luxurious face cream for your evening routine.',pricePaise:49900,stock:30},
 {id:'p4',name:'Hair Growth Oil',category:'Hair Care',description:'A botanical-inspired hair oil for scalp massage.',pricePaise:39900,stock:30},
 {id:'p5',name:'Ubtan Face Pack',category:'Body Care',description:'A traditional-inspired powder face pack.',pricePaise:32500,stock:30},
 {id:'p6',name:'Rose Water Toner',category:'Face Care',description:'A light floral mist for your skincare routine.',pricePaise:24900,stock:40}
];
const safeUser=u=>({id:u.id,name:u.name,email:u.email,role:u.role});
const auth=(req,res,next)=>{try{const h=req.headers.authorization||'';const token=h.startsWith('Bearer ')?h.slice(7):'';req.user=jwt.verify(token,process.env.JWT_SECRET);next()}catch{return res.status(401).json({error:'Authentication required'})}};
const admin=(req,res,next)=>req.user?.role==='ADMIN'?next():res.status(403).json({error:'Admin access required'});

app.get('/api/health',(req,res)=>res.json({ok:true,service:'MOONIE — Beauty & Wellness API'}));
app.get('/api/products',async(req,res)=>{try{const data=await prisma.product.findMany({where:{active:true},orderBy:{createdAt:'desc'}});res.json(data.length?data:productsSeed)}catch{res.json(productsSeed)}});
app.post('/api/auth/register',async(req,res)=>{try{const {name,email,password,phone}=req.body;if(!name||!email||!password||password.length<8)return res.status(400).json({error:'Name, valid email and password (8+ characters) required'});const passwordHash=await bcrypt.hash(password,12);const user=await prisma.user.create({data:{name,email:email.toLowerCase(),phone,passwordHash}});const token=jwt.sign({id:user.id,role:user.role},process.env.JWT_SECRET,{expiresIn:'2h'});res.status(201).json({token,user:safeUser(user)})}catch(e){res.status(400).json({error:'Could not create account. Email may already be registered.'})}});
app.post('/api/auth/login',async(req,res)=>{try{const {email,password}=req.body;const user=await prisma.user.findUnique({where:{email:email?.toLowerCase()}});if(!user||!(await bcrypt.compare(password||'',user.passwordHash)))return res.status(401).json({error:'Invalid email or password'});const token=jwt.sign({id:user.id,role:user.role},process.env.JWT_SECRET,{expiresIn:'2h'});res.json({token,user:safeUser(user)})}catch{return res.status(500).json({error:'Login unavailable'})}});
async function makeOrder({items,customer,paymentMethod,razorpayOrderId}){
 if(!Array.isArray(items)||items.length<1)throw new Error('Cart is empty');
 if(!customer?.name||!customer?.phone||!customer?.address||!customer?.pincode)throw new Error('Delivery details are incomplete');
 const ids=[...new Set(items.map(i=>i.productId))];
 const dbProducts=await prisma.product.findMany({where:{id:{in:ids},active:true}});
 const byId=new Map(dbProducts.map(p=>[p.id,p]));
 let subtotalPaise=0;const orderItems=[];
 for(const item of items){const p=byId.get(item.productId);const qty=Number(item.quantity);if(!p||!Number.isInteger(qty)||qty<1||qty>20)throw new Error('Invalid product or quantity');if(p.stock<qty)throw new Error(`Insufficient stock for ${p.name}`);subtotalPaise+=p.pricePaise*qty;orderItems.push({productId:p.id,quantity:qty,unitPricePaise:p.pricePaise})}
 return prisma.order.create({data:{customerName:customer.name,customerEmail:customer.email||null,customerPhone:customer.phone,address:customer.address,pincode:customer.pincode,subtotalPaise,paymentMethod,paymentStatus:paymentMethod==='COD'?'PENDING':'PENDING',orderStatus:'PLACED',razorpayOrderId,items:{create:orderItems}}});
}
app.post('/api/orders/cod',async(req,res)=>{try{const order=await makeOrder({items:req.body.items,customer:req.body.customer,paymentMethod:'COD'});res.status(201).json({orderId:order.id,status:order.orderStatus,paymentMethod:'COD'})}catch(e){res.status(400).json({error:e.message||'Could not place order'})}});
app.post('/api/payments/create-order',async(req,res)=>{try{if(!process.env.RAZORPAY_KEY_ID||!process.env.RAZORPAY_KEY_SECRET)return res.status(503).json({error:'Online payments are not configured'});const items=req.body.items;const customer=req.body.customer;if(!Array.isArray(items)||!items.length)return res.status(400).json({error:'Cart is empty'});const ids=[...new Set(items.map(i=>i.productId))];const ps=await prisma.product.findMany({where:{id:{in:ids},active:true}});const map=new Map(ps.map(p=>[p.id,p]));let amount=0;for(const it of items){const p=map.get(it.productId),q=Number(it.quantity);if(!p||!Number.isInteger(q)||q<1||q>20||p.stock<q)return res.status(400).json({error:'Invalid product or stock'});amount+=p.pricePaise*q}const rz=new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});const rp=await rz.orders.create({amount,currency:'INR',receipt:`moon_${Date.now()}`});const order=await makeOrder({items,customer,paymentMethod:'RAZORPAY',razorpayOrderId:rp.id});res.status(201).json({orderId:order.id,razorpayOrderId:rp.id,amount:rp.amount,currency:rp.currency,keyId:process.env.RAZORPAY_KEY_ID})}catch(e){res.status(400).json({error:e.message||'Payment order could not be created'})}});
app.post('/api/payments/verify',async(req,res)=>{try{const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');if(!razorpay_signature||!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(razorpay_signature)))return res.status(400).json({error:'Invalid payment signature'});const order=await prisma.order.findUnique({where:{razorpayOrderId:razorpay_order_id}});if(!order)return res.status(404).json({error:'Order not found'});const updated=await prisma.order.update({where:{id:order.id},data:{paymentStatus:'PAID',orderStatus:'CONFIRMED',razorpayPaymentId:razorpay_payment_id}});res.json({ok:true,orderId:updated.id,status:updated.orderStatus})}catch{return res.status(400).json({error:'Could not verify payment'})}});
app.post('/api/payments/webhook',express.raw({type:'application/json'}),async(req,res)=>{try{const sig=req.headers['x-razorpay-signature'];const expected=crypto.createHmac('sha256',process.env.RAZORPAY_WEBHOOK_SECRET||'').update(req.body).digest('hex');if(!sig||!process.env.RAZORPAY_WEBHOOK_SECRET||sig!==expected)return res.status(400).send('Invalid signature');const event=JSON.parse(req.body.toString());if(event.event==='payment.captured'){const payment=event.payload.payment.entity;await prisma.order.updateMany({where:{razorpayOrderId:payment.order_id},data:{paymentStatus:'PAID',orderStatus:'CONFIRMED',razorpayPaymentId:payment.id}})}res.json({received:true})}catch{return res.status(400).send('Webhook error')}});
app.get('/api/orders/mine',auth,async(req,res)=>{const orders=await prisma.order.findMany({where:{userId:req.user.id},include:{items:{include:{product:true}}},orderBy:{createdAt:'desc'}});res.json(orders)});
app.get('/api/admin/orders',auth,admin,async(req,res)=>{const orders=await prisma.order.findMany({include:{items:{include:{product:true}}},orderBy:{createdAt:'desc'}});res.json(orders)});
app.post('/api/admin/products',auth,admin,async(req,res)=>{try{const p=await prisma.product.create({data:req.body});res.status(201).json(p)}catch{return res.status(400).json({error:'Invalid product data'})}});
app.patch('/api/admin/orders/:id',auth,admin,async(req,res)=>{const {orderStatus}=req.body;const allowed=['PLACED','CONFIRMED','PACKED','SHIPPED','OUT_FOR_DELIVERY','DELIVERED','CANCELLED'];if(!allowed.includes(orderStatus))return res.status(400).json({error:'Invalid order status'});const order=await prisma.order.update({where:{id:req.params.id},data:{orderStatus}});res.json(order)});
const port=process.env.PORT||4000;
app.listen(port,()=>console.log(`MOONIE — Beauty & Wellness API listening on ${port}`));
